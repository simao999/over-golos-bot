import os
import time
from telegram import Bot

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
bot = Bot(token=BOT_TOKEN)

def main():
    while True:
        # Exemplo de mensagem fictícia a cada 5 minutos
        message = (
            "⚽ Jogo: Arsenal vs Man City\n"
            "⏱ Minuto: 67 | Resultado: 0-1\n"
            "Pressão: Alta | Ataques perigosos: 38\n"
            "Probabilidade de +1.5: 78%\n"
            "Sinal: Recomendado Over 1.5 golos!"
        )
        bot.send_message(chat_id=CHAT_ID, text=message)
        time.sleep(300)

if __name__ == "__main__":
    main()